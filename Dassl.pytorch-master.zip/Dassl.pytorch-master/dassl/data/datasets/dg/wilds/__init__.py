from .fmow import FMoW
from .iwildcam import IWildCam
from .camelyon17 import Camelyon17
